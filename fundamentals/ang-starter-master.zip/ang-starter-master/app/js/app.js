/**
 * Created by Maikel Rivero Dorta mriverodorta@gmail.com on 7/08/14.
 */
"use strict";
// Declaramos la aplicacion y definimos sus dependencias
angular.module('AngStarter', ['ngRoute']);

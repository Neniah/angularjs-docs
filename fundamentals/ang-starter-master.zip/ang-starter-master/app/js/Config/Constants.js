/**
 * Created by Maikel Rivero Dorta mriverodorta@gmail.com on 7/08/14.
 */
'use strict';
angular.module('AngStarter') 
    .constant('CSRF_TOKEN', {_token: 'TOKEN-HERE'});
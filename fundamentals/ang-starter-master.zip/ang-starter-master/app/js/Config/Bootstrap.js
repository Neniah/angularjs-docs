/**
 * Created by Maikel Rivero Dorta mriverodorta@gmail.com on 7/08/14.
 */
'use strict';
angular.module('AngStarter')
.run(['$rootScope', function ($rootScope) {

    /**
     * Do something here when the app start
     */
    
}]);